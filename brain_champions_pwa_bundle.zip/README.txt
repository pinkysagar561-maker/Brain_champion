BRAIN CHAMPIONS — PWA package
This folder is prepared for hosting as a Progressive Web App (PWA).
Important: this ZIP is NOT an APK.

Next:
1. Upload the contents of this folder to an HTTPS web host (not the ZIP itself as a download link).
2. Open the hosted HTTPS URL in Chrome on Android to test.
3. Use PWABuilder.com with that public HTTPS URL to package for Android. PWABuilder requires a hosted PWA URL.
4. Test the resulting APK before installing. Keep signing-key files private and safe.
